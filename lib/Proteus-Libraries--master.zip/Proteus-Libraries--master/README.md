# Proteus-Libraries-
Proteus commonly used Libraries compilation

# To Add this liberaries Simply you need to copy (.LIB and .IDX) files to LIBERARY folder of Proteus.
# For some components you also required to copy .HEX example ultraSonic copy .HEX with (.LIB and .IDX).

LIBERARY folder in proteus 8.9 and above is located in Program Data folder:
===> Similar to this path [ C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\LIBRARY ]

Injoy.....
